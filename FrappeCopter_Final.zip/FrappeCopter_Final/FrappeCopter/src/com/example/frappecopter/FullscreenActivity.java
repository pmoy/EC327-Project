package com.example.frappecopter;

import com.example.frappecopter.util.SystemUiHider;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.widget.RadioButton;


public class FullscreenActivity extends Activity {

	// Global variable to control speed of game
	int speed = 3; // Initialize to easy for the weak

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_fullscreen);

		
	}
	
	// Set speed based on difficulty
	public void set_speed(View v) {
		RadioButton button = (RadioButton)v;
		// Check to see if radiobutton is checked
		if(button.isChecked()) {
			// Set speed based on id of checked radiobutton
			switch(button.getId()) {
				case R.id.radioButton1:
					// Easy
					speed = 3;
					break;
				case R.id.radioButton2:
					// Medium
					speed = 5;
					break;
				case R.id.radioButton3:
					// Hard
					speed = 10;
					break;
			}
		}
		return;
	}
	
	// Transition to the next screen
	public void show_instructions(View v) {
		// Make new intent object to pass speed to instructions screen
		Intent instructions = new Intent(this, Instructions.class);
		
		// Pass speed along to instructions screen
		instructions.putExtra("speed", speed);
		
		// Start Instructions
		startActivity(instructions);
	}
}
