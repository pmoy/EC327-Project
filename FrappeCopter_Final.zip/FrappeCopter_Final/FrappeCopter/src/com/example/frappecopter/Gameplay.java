package com.example.frappecopter;

import com.example.frappecopter.util.SystemUiHider;

import android.annotation.TargetApi;
import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;


public class Gameplay extends Activity {
	
	// Instantiate GameView to control Gameplay
	GameView game;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_gameplay);
		
		// Set game to our canvas in the .xml file
		game = (GameView)findViewById(R.id.view1);

		// Get speed passed from instructions activity
		game.set_speed(getIntent().getIntExtra("speed", 3));
		
		// Set up touch listener to make frappe go up instead of down
		View rl = findViewById(R.id.relativelayout);
		rl.setOnTouchListener(new View.OnTouchListener() {
			@Override
			public boolean onTouch(View view, MotionEvent motionEvent) {
				// Make that frappe go up!
				game.fly();
				return true;
			}
		});
		
	}


}

