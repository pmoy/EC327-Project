package com.example.frappecopter;

import com.example.frappecopter.util.SystemUiHider;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;


public class DeadScreen extends Activity {
	
	// Final score!
	double score;
	// Field to display score
	TextView display_score;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_dead_screen);
		
		// Get final score from Gameplay
		score = getIntent().getDoubleExtra("score", 0.0);
		
		// Display score - cast as an integer to avoid gross numbers
		int int_score = (int)score;
		display_score = (TextView)findViewById(R.id.score);
		display_score.setText("" + int_score);
		
		return;
	}
	
	// Play again button - send back to FullscreenActivity
	public void restart_game(View v) {
		Intent restart = new Intent(this, FullscreenActivity.class);
		
		startActivity(restart);
		return;
	}
}
