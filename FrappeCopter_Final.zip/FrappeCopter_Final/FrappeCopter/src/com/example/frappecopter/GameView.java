package com.example.frappecopter;

import java.util.ArrayList;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

// Canvas for drawing game objects
public class GameView extends View implements Runnable {

	// Variables... TBD
	private Paint paint;
	//Array containing possible pictures of vegetables
	ArrayList<Bitmap> choice;
	// Current score of player
	double score;
	// Time game has gone on for
	double time;
	// Speed of game
	int speed;
	// width and height of the canvas for drawing purposes
	int width;
	int height;
	// sizes for frappe image
	int frappe_width;
	int frappe_height;
	// sizes for vegetable images
	int veggie_width;
	int veggie_height;
	// Declare objects
	Vegetable veggie_1;
	Vegetable veggie_2;
	Frappe frappe;
	// Is the frappe going up or down?
	boolean going_up;
	
	// Thread responsible for running game
	public Thread play_game;
	
	// Construct a GameView object
	public GameView(Context context, AttributeSet attrs) {
		super(context, attrs);
		// Initialize variables
		score = 0.0;
		time = 0.0;
		// Get vegetable images
		choice = new ArrayList<Bitmap>();
		
		// Create thread to implement run method 
		play_game = new Thread(this);
		
	}

	
	// Functions
	@Override
	public void run() {
		// main method of the program
		
		while (frappe.is_alive()) {
			// Run this until the player fails, then break
			
			// Move frappe down
			frappe.increment_y(speed);
			// Move vegetables to the left
			veggie_1.decrement_x(speed);
			veggie_2.decrement_x(speed);
			// Test if vegetable is off the screen - if so, move all the way to the right, change image, set random y-coord
			if (veggie_1.getx_coord() <= 0) {
				veggie_1.setx_coord(2*width - 2*veggie_width);
				veggie_1.change_veggie(choice);
				veggie_1.set_random_height();
			}
			if (veggie_2.getx_coord() <= 0) {
				veggie_2.setx_coord(2*width - 2*veggie_width);
				veggie_2.change_veggie(choice);
				veggie_2.set_random_height();
			}
			// Increment time
			time += 0.05;
			// set score
			score = time * 100;
			// Check to see if collisions have occurred, aka player should be dead
			// Check if frappe is within the height range of a vegetable, then if it is, check if it's also within width
			if ((frappe.gety_coord() > veggie_1.gety_coord()) && (frappe.gety_coord() < veggie_1.gety_coord() + veggie_height)) {
				if ((frappe.getx_coord() > veggie_1.getx_coord()) && (frappe.getx_coord() < veggie_1.getx_coord() + veggie_width))
					frappe.kill_frappe();
				else if ((frappe.getx_coord() + frappe_width > veggie_1.getx_coord()) && (frappe.getx_coord() + frappe_width < veggie_1.getx_coord() + veggie_width))
					frappe.kill_frappe();
			}
			else if ((frappe.gety_coord() + frappe_height > veggie_1.gety_coord()) && (frappe.gety_coord() + frappe_height < veggie_1.gety_coord() + veggie_height)) {
				if ((frappe.getx_coord() > veggie_1.getx_coord()) && (frappe.getx_coord() < veggie_1.getx_coord() + veggie_width))
					frappe.kill_frappe();
				else if ((frappe.getx_coord() + frappe_width > veggie_1.getx_coord()) && (frappe.getx_coord() + frappe_width < veggie_1.getx_coord() + veggie_width))
					frappe.kill_frappe();
			}
			// Check second veggie in the same manner
			if ((frappe.gety_coord() > veggie_2.gety_coord()) && (frappe.gety_coord() < veggie_2.gety_coord() + veggie_height)) {
				if ((frappe.getx_coord() > veggie_2.getx_coord()) && (frappe.getx_coord() < veggie_2.getx_coord() + veggie_width))
					frappe.kill_frappe();
				else if ((frappe.getx_coord() + frappe_width > veggie_2.getx_coord()) && (frappe.getx_coord() + frappe_width < veggie_2.getx_coord() + veggie_width))
					frappe.kill_frappe();
			}
			else if ((frappe.gety_coord() + frappe_height > veggie_2.gety_coord()) && (frappe.gety_coord() + frappe_height < veggie_2.gety_coord() + veggie_height)) {
				if ((frappe.getx_coord() > veggie_2.getx_coord()) && (frappe.getx_coord() < veggie_2.getx_coord() + veggie_width))
					frappe.kill_frappe();
				else if ((frappe.getx_coord() + frappe_width > veggie_2.getx_coord()) && (frappe.getx_coord() + frappe_width < veggie_2.getx_coord() + veggie_width))
					frappe.kill_frappe();
			}
			// Check if frappe is hitting the boundaries of the view - this is crashing into bricks
			if (frappe.gety_coord() < 0)
				frappe.kill_frappe();
			if (frappe.gety_coord() + frappe_height > height)
				frappe.kill_frappe();
			// Reset canvas
			postInvalidate();
			
			// Pause the thread so it doesn't freak out
			try {
	            Thread.sleep(50);
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }
		}
		
		// Player has died - transition to next screen
		next_screen();
	}
	
	@Override
	protected void onDraw(Canvas canvas) {
		// Draw objects
		veggie_1.draw_self(canvas);
		veggie_2.draw_self(canvas);
		frappe.draw_self(canvas);
	}
	
	// Get coordinates of canvas, create objects and run game - happens when size of canvas is determined
	@Override
	protected void onSizeChanged(int xNew, int yNew, int xOld, int yOld)
	{
		super.onSizeChanged(xNew, yNew, xOld, yOld);
		
		// Set global width and height
		width = xNew;
	    height = yNew;
	    // Set global vegetable size parameters
	    veggie_width = (width / 10);
	    veggie_height = (height / 3);
	    // Set global frappe size parameters
	    frappe_width = (width / 5);
	    frappe_height = (height / 10);
	    // Set up ArrayList of veggie images
	    setup_choice(choice);
	    
	    // Create our vegetable objects - offset to initially create them off screen, then move onto screen
	    veggie_1 = new Vegetable(choice, veggie_width, veggie_height, speed, 1);
	    veggie_2 = new Vegetable(choice, veggie_width, veggie_height, speed, 2);
	    // Construct one frappe object
	    Bitmap frappe_image = BitmapFactory.decodeResource(getResources(), R.drawable.oreo_frappe);
	 	frappe = new Frappe(getResizedBitmap(frappe_image, frappe_height, frappe_width), frappe_width, frappe_height);
	 	
	 	// LET'S PLAY
	 	play_game.start();
	}
	
	// Resize bitmap to fit screen - courtesy of stackoverflow
	public Bitmap getResizedBitmap(Bitmap bm, int newHeight, int newWidth)
	{
		int width = bm.getWidth();
		int height = bm.getHeight();
		float scaleWidth = ((float) newWidth) / width;
		float scaleHeight = ((float) newHeight) / height;
		// create a matrix for the manipulation
		Matrix matrix = new Matrix();
		// resize the bit map
		matrix.postScale(scaleWidth, scaleHeight);
		// recreate the new Bitmap
		Bitmap resizedBitmap = Bitmap.createBitmap(bm, 0, 0, width, height, matrix, false);
		return resizedBitmap;
	}
	
	// Set up the ArrayList choice with correct sizes of images
	public void setup_choice(ArrayList<Bitmap> choice) {
		// Get images
		Bitmap broccoli = BitmapFactory.decodeResource(getResources(), R.drawable.broccoli);
		Bitmap celery = BitmapFactory.decodeResource(getResources(), R.drawable.celery);
		Bitmap carrot = BitmapFactory.decodeResource(getResources(), R.drawable.carrot);
		Bitmap mushroom = BitmapFactory.decodeResource(getResources(), R.drawable.mushroom);
		Bitmap radish = BitmapFactory.decodeResource(getResources(), R.drawable.radish);
		
		// Put resized images into ArrayList
		choice.add(getResizedBitmap(broccoli, veggie_height, veggie_width));
		choice.add(getResizedBitmap(celery, veggie_height, veggie_width));
		choice.add(getResizedBitmap(carrot, veggie_height, veggie_width));
		choice.add(getResizedBitmap(mushroom, veggie_height, veggie_width));
		choice.add(getResizedBitmap(radish, veggie_height, veggie_width));
	}
	
	// Set speed of game
	public void set_speed(int input_speed) {
		speed = input_speed;
		return;
	}
	
	// Move frappe up - needed for touch listener
	public void fly() {
		// Note decrease in y coordinates actually moves frappe up
		frappe.increment_y(-3 * speed);
		return;
	}
	
	// Move to deadscreen - game has ended
	public void next_screen() {
		// Make new intent object to pass speed to dead screen
		Intent dead = new Intent(this.getContext(), DeadScreen.class);
					
		// Pass speed along to dead screen
		dead.putExtra("score", score);
					
		// Start DeadScreen
		getContext().startActivity(dead);
	}
}


/******** LOGIC FOR GAME ***************

test if player is still alive
move all vegetable objects to the left
	test if vegetable is off screen, if so move all the way to the right and change bitmap
increment time
increment and display score
redraw all objects

if player has died, stop and move to the next screen
**************************/
